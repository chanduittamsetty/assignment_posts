import React from "react";
import "./styles.css";
import {Posts} from "./components/Post"
export default function App() {

  return (
    <div>
      <Posts/>
    </div>
  );
}
